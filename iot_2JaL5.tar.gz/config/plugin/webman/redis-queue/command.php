<?php

use Webman\RedisQueue\Command\MakeConsumerCommand;

return [
    MakeConsumerCommand::class
];