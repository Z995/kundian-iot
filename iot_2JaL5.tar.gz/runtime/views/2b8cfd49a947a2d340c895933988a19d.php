<?php /*a:3:{s:41:"/www/wwwroot/iot/app/view/keys/index.html";i:1733204298;s:42:"/www/wwwroot/iot/app/view/Public/head.html";i:1733021756;s:45:"/www/wwwroot/iot/app/view/Public/sidebar.html";i:1733099456;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
<title>IOT物联网系统</title>
<meta content="width=device-width, initial-scale=1.0,user-scalable=no" name="viewport" />
<meta name="renderer" content="webkit" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="shortcut icon" href="/static/media/image/favicon.ico" />
<script src="/static/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/static/js/vue.js"></script>
<link href="/static/css/css.css" rel="stylesheet" type="text/css" />
<link href="/static/js/layui/css/layui.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/static/js/layui/layui.js"></script>
<script type="text/javascript" src="/static/js/laydate/laydate.js"></script>
<script type="text/javascript">
    layui.use(['layer'], function () {
        var layer = layui.layer
    });

</script>
<style>
    [v-cloak] {
        display: none;
    }
</style>
    <meta name="viewport" content="width=960,target-densitydpi=device-dpi user-scalable=yes" />
    <link href="/static/media/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-responsive.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/default.css" rel="stylesheet" type="text/css" id="style_color" />
    <link href="/static/media/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-metro.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/uniform.default.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="/static/media/css/select2_metro.css" />
    <link rel="stylesheet" type="text/css" href="/static/media/css/chosen.css" />
    <style>
        .red {
            color: red;
        }
    </style>
</head>

<body class="page-header-fixed">
    <div class="page-container">
        <div class="page-sidebar nav-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->
    <div class="user-div">
        <span class="title sidebar-title">admin</span>
    </div>
    <ul class="page-sidebar-menu">
        <li class="start">
            <a href="http://60.247.225.87:6767/main">
                <i class="icon-home"></i>
                <span class="title">
                    主菜单
                </span>
                <span class="selected"></span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/iot/index">
                <i class="icon-sitemap"></i>
                <span class="title"> 设备列表</span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/keys/index">
                <i class="icon-sitemap"></i>
                <span class="title"> API密钥</span>
            </a>
        </li>
        <li>
            <a href="javascript:;" class="login_out">
                <i class="icon-sitemap"></i>
                <span class="title"> 退出</span>
            </a>
        </li>
    </ul>
    <!-- END SIDEBAR MENU -->
</div>
<script>
    $(function () {
        $(".login_out").click(function () {
            layer.confirm('确定要安全退出吗?', {
                title: '提示',
                btn: ['确定', '取消']
            }, function () {
                layer.closeAll();
                layer.msg('正在退出...', { icon: 16, shift: 2, time: 0, shade: [0.1, '#000'] });
                $.ajax({
                    type: 'post',
                    url: "http://60.247.225.87:6767/index/login_out",
                    dataType: 'json',
                    success: function (d) {
                        layer.msg(d.msg);
                        setTimeout(function () {
                            window.location.href = "http://60.247.225.87:6767/index";
                        }, 1000);
                    }
                });
            });
        });
    });
    window.onload = function () {
        $(".page-sidebar-menu li").each(function () {
            var th = this;
            if($(th).find('a').attr('href').indexOf(window.location.href.replace('http://60.247.225.87:6767','')) != -1) {
                $(th).addClass('open');
            }
        });};
</script>
        <div class="page-content">
            <div>
                <div class="tab-pane active" id="app" v-cloak>
                    <div class="portlet box yellow ">
                        <div class="portlet-body">
                            <div style="margin-top:10px;padding: 0 20px;">
                                <a href="javascript:;" class="layui-btn add" @click="add('')">添加</a>
                            </div>
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>
                                            名称
                                        </th>
                                        <th>
                                            api_key
                                        </th>
                                        <th>
                                            api_secret
                                        </th>
                                        <th>
                                            过期时间
                                        </th>
                                        <th>
                                            状态
                                        </th>
                                        <th>
                                            操作
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in list">
                                        <td>
                                            {{item.name}}
                                        </td>
                                        <td>
                                            {{item.api_key}}
                                        </td>
                                        <td>
                                            {{item.api_secret}}
                                        </td>
                                        <td>
                                            {{item.expire_time}}
                                        </td>
                                        <td>
                                            {{item.statusName}}
                                        </td>
                                        <td>
                                            <a href="javascript:;" @click="add(item.id)">编辑</a>
                                            <a href="javascript:;" @click="del(index)">删除</a>
                                        </td>
                                    </tr>
                                    </volist>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/static/media/js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="/static/media/js/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
    <script src="/static/media/js/bootstrap.min.js" type="text/javascript"></script>
    <!--[if lt IE 9]>
            <script src="/static/media/js/excanvas.min.js">
            </script>
            <script src="/static/media/js/respond.min.js">
            </script>
        <![endif]-->
    <script type="text/javascript" src="/static/media/js/chosen.jquery.min.js"></script>
    <script src="/static/media/js/app.js" type="text/javascript"></script>
    <script src="/static/media/js/jquery.uniform.min.js" type="text/javascript"></script>
    <script src="/static/js/plupload.full.min.js" type="text/javascript"></script>
    <script>
        var app = {};
        jQuery(document).ready(function () {
            App.init(); // initlayout and core plugins
        });
        layui.use(['layer'], function () {
            var layer = layui.layer
            app = new Vue({
                el: '#app',
                data: {
                    list: [],
                    ws: {},
                    member: {}
                },
                created: function () {
                    var th = this;
                    th.getList();
                },
                methods: {
                    getList: function () {
                        var th = this;
                        try {
                            layer.msg('加载中...', { icon: 16, shade: [0.1, '#000'], area: '180px', time: 0 });
                        } catch (e) { }
                        $.ajax({
                            type: 'post',
                            url: 'http://60.247.225.87:6767/keys/getList',
                            data: {
                            },
                            timeout: 35000,
                            dataType: 'json',
                            success: function (data) {
                                try {
                                    layer.closeAll();
                                } catch (e) { }
                                if (data.code == 0) {
                                    th.list = data.data;
                                } else {
                                    layer.alert(data.msg);
                                }
                            }
                        });
                    },
                    //添加设备
                    add: function (id) {
                        //点击名称出现详情
                        var index = layer.open({
                            title: '操作',
                            type: 2,
                            content: 'http://60.247.225.87:6767/keys/add?id=' + id,
                            area: ['700px', '720px'],
                            maxmin: true
                        });
                    },
                    //移除设备
                    del: function (index) {
                        var th = this;
                        layer.confirm('确定移除该密钥？', function (idx) {
                            layer.msg('操作中...', { icon: 16, shade: [0.1, '#000'], area: '180px', time: 0 });
                            $.ajax({
                                type: 'post',
                                url: "http://60.247.225.87:6767/keys/delAjax",
                                timeout: 5000,
                                data: {
                                    id: th.list[index].id,
                                    index: index
                                },
                                dataType: 'json',
                                success: function (data) {
                                    layer.closeAll();
                                    layer.msg(data.info);
                                    if (data.status == 'success') {
                                        th.list.splice(data.index, 1);
                                    }
                                }
                            });
                        });
                    },
                },
            });
        });
    </script>
    <!-- END JAVASCRIPTS -->
    <!-- END BODY -->
</body>

</html>