<?php /*a:3:{s:39:"/www/wwwroot/iot/app/view/iot/logs.html";i:1733021756;s:42:"/www/wwwroot/iot/app/view/Public/head.html";i:1733021756;s:45:"/www/wwwroot/iot/app/view/Public/sidebar.html";i:1733099456;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
<title>IOT物联网系统</title>
<meta content="width=device-width, initial-scale=1.0,user-scalable=no" name="viewport" />
<meta name="renderer" content="webkit" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="shortcut icon" href="/static/media/image/favicon.ico" />
<script src="/static/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/static/js/vue.js"></script>
<link href="/static/css/css.css" rel="stylesheet" type="text/css" />
<link href="/static/js/layui/css/layui.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/static/js/layui/layui.js"></script>
<script type="text/javascript" src="/static/js/laydate/laydate.js"></script>
<script type="text/javascript">
    layui.use(['layer'], function () {
        var layer = layui.layer
    });

</script>
<style>
    [v-cloak] {
        display: none;
    }
</style>
    <link href="/static/media/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-responsive.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-metro.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/default.css" rel="stylesheet" type="text/css" id="style_color" />
    <link href="/static/media/css/DT_bootstrap.css" rel="stylesheet" type="text/css" />
    <style>
        table td {
            word-break: break-all
        }
    </style>
</head>

<body class="page-header-fixed">
    <div class="page-container">
        <div class="page-sidebar nav-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->
    <div class="user-div">
        <span class="title sidebar-title">admin</span>
    </div>
    <ul class="page-sidebar-menu">
        <li class="start">
            <a href="http://60.247.225.87:6767/main">
                <i class="icon-home"></i>
                <span class="title">
                    主菜单
                </span>
                <span class="selected"></span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/iot/index">
                <i class="icon-sitemap"></i>
                <span class="title"> 设备列表</span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/keys/index">
                <i class="icon-sitemap"></i>
                <span class="title"> API密钥</span>
            </a>
        </li>
        <li>
            <a href="javascript:;" class="login_out">
                <i class="icon-sitemap"></i>
                <span class="title"> 退出</span>
            </a>
        </li>
    </ul>
    <!-- END SIDEBAR MENU -->
</div>
<script>
    $(function () {
        $(".login_out").click(function () {
            layer.confirm('确定要安全退出吗?', {
                title: '提示',
                btn: ['确定', '取消']
            }, function () {
                layer.closeAll();
                layer.msg('正在退出...', { icon: 16, shift: 2, time: 0, shade: [0.1, '#000'] });
                $.ajax({
                    type: 'post',
                    url: "http://60.247.225.87:6767/index/login_out",
                    dataType: 'json',
                    success: function (d) {
                        layer.msg(d.msg);
                        setTimeout(function () {
                            window.location.href = "http://60.247.225.87:6767/index";
                        }, 1000);
                    }
                });
            });
        });
    });
    window.onload = function () {
        $(".page-sidebar-menu li").each(function () {
            var th = this;
            if($(th).find('a').attr('href').indexOf(window.location.href.replace('http://60.247.225.87:6767','')) != -1) {
                $(th).addClass('open');
            }
        });};
</script>
        <div class="page-content">
            <div>
                <!-- BEGIN BORDERED TABLE PORTLET-->
                <div class="portlet box yellow" style="border:none;">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-calendar">
                            </i> 设备数据日志
                        </div>
                    </div>
                    <div class="search">
                        <p><?php echo $search_year; ?></p>
                        <p><?php echo $search_month; ?></p>
                        <p><?php echo $search_day; ?></p>
                    </div>
                    <form action="" id="form" method="get">
                        <input type="hidden" name="year" value="<?php echo htmlentities(((request()->all())['year'] ?? '')); ?>">
                        <input type="hidden" name="month" value="<?php echo htmlentities(((request()->all())['month'] ?? '')); ?>">
                        <input type="hidden" name="day" value="<?php echo htmlentities(((request()->all())['day'] ?? '')); ?>">
                        <!-- <div style="margin-top:10px;padding: 0 20px;">控制器：
                            <input type="text" placeholder="多个编号用逗号分隔" class="m-wrap" name="controller"
                                value="<?php echo htmlentities(((request()->all())['controller'] ?? '')); ?>" style="width: 150px;">
                            <button type="submit" class="btn green">搜索 &nbsp; <i
                                    class="m-icon-swapright m-icon-white"></i></button>
                        </div> -->
                    </form>
                    <div class="portlet-body">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        协议类型
                                    </th>
                                    <th>
                                        数据类型/主题
                                    </th>
                                    <th>
                                        数据内容
                                    </th>
                                    <th style="width:10%;">
                                        时间
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                    <tr class="tr_<?php echo htmlentities($vo['id']); ?>">
                                        <td>
                                            <?php echo htmlentities($vo['typeName']); ?>
                                        </td>
                                        <td>
                                            <?php if($vo['type'] != 2): ?>
                                                <?php echo htmlentities($vo['vtypeName']); else: ?>
                                                <?php echo htmlentities($vo['topic']); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo htmlentities($vo['val']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlentities($vo['addtime']); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </tbody>
                        </table>
                        <div class="digg"><?php echo $page; ?></div>
                        <?php if(empty($list)): ?>
                            <p style="text-align: center;">暂无数据</p>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- END BORDERED TABLE PORTLET-->
            </div>
        </div>
    </div>
    <script src="/static/media/js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="/static/media/js/bootstrap.min.js" type="text/javascript"></script>
    <!--[if lt IE 9]>
            <script src="/static/media/js/excanvas.min.js">
            </script>
            <script src="/static/media/js/respond.min.js">
            </script>
        <![endif]-->
    <script src="/static/media/js/app.js" type="text/javascript"></script>
    <script>
        jQuery(document).ready(function () {
            App.init(); // initlayout and core plugins
        });
    </script>
    <!-- END JAVASCRIPTS -->
    <!-- END BODY -->
</body>

</html>