<?php /*a:3:{s:41:"/www/wwwroot/iot/app/view/main/index.html";i:1733021756;s:42:"/www/wwwroot/iot/app/view/Public/head.html";i:1733021756;s:45:"/www/wwwroot/iot/app/view/Public/sidebar.html";i:1733099456;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
<title>IOT物联网系统</title>
<meta content="width=device-width, initial-scale=1.0,user-scalable=no" name="viewport" />
<meta name="renderer" content="webkit" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="shortcut icon" href="/static/media/image/favicon.ico" />
<script src="/static/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/static/js/vue.js"></script>
<link href="/static/css/css.css" rel="stylesheet" type="text/css" />
<link href="/static/js/layui/css/layui.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/static/js/layui/layui.js"></script>
<script type="text/javascript" src="/static/js/laydate/laydate.js"></script>
<script type="text/javascript">
    layui.use(['layer'], function () {
        var layer = layui.layer
    });

</script>
<style>
    [v-cloak] {
        display: none;
    }
</style>
        <link href="/static/media/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="/static/media/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="/static/media/css/style.css" rel="stylesheet" type="text/css" />
        <link href="/static/media/css/style-responsive.css" rel="stylesheet" type="text/css" />
        <link href="/static/media/css/default.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="/static/media/css/style-metro.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            .main {
                width: 100%;
                height: auto;
            }

            .main_01 {
                width: 95%;
                height: auto;
                margin: 0 auto;
            }

            .main .title {
                width: 100%;
                height: 40px;
                color: #34393f;
                font-size: 16px;
                line-height: 40px;
                border-bottom: 1px solid #ededed;
                margin: 0 auto;
            }

            .main .one {
                width: 21%;
                max-width: 90px;
                float: left;
                margin: 5px;
                text-align: center;
                padding-top: 10px;
            }

            .main .one .span-01 {
                border-radius: 10px !important;
                width: 100%;
                height: 50px;
                margin: 0 auto;
                text-align: center;
                line-height: 50px;
                color: #fff;
                padding-top: 5px;
            }

            .main .one .span-02 {
                width: 100%;
                height: 30px;
                line-height: 30px;
                text-align: center;
                color: #1d1a25;
                margin: 0 auto;
            }

            .main .one i {
                margin: 0 auto;
            }

            .clear {
                clear: both;
            }
        </style>
</head>

<body class="page-header-fixed">
        <div class="page-container">
            <div class="page-sidebar nav-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->
    <div class="user-div">
        <span class="title sidebar-title">admin</span>
    </div>
    <ul class="page-sidebar-menu">
        <li class="start">
            <a href="http://60.247.225.87:6767/main">
                <i class="icon-home"></i>
                <span class="title">
                    主菜单
                </span>
                <span class="selected"></span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/iot/index">
                <i class="icon-sitemap"></i>
                <span class="title"> 设备列表</span>
            </a>
        </li>
        <li>
            <a href="http://60.247.225.87:6767/keys/index">
                <i class="icon-sitemap"></i>
                <span class="title"> API密钥</span>
            </a>
        </li>
        <li>
            <a href="javascript:;" class="login_out">
                <i class="icon-sitemap"></i>
                <span class="title"> 退出</span>
            </a>
        </li>
    </ul>
    <!-- END SIDEBAR MENU -->
</div>
<script>
    $(function () {
        $(".login_out").click(function () {
            layer.confirm('确定要安全退出吗?', {
                title: '提示',
                btn: ['确定', '取消']
            }, function () {
                layer.closeAll();
                layer.msg('正在退出...', { icon: 16, shift: 2, time: 0, shade: [0.1, '#000'] });
                $.ajax({
                    type: 'post',
                    url: "http://60.247.225.87:6767/index/login_out",
                    dataType: 'json',
                    success: function (d) {
                        layer.msg(d.msg);
                        setTimeout(function () {
                            window.location.href = "http://60.247.225.87:6767/index";
                        }, 1000);
                    }
                });
            });
        });
    });
    window.onload = function () {
        $(".page-sidebar-menu li").each(function () {
            var th = this;
            if($(th).find('a').attr('href').indexOf(window.location.href.replace('http://60.247.225.87:6767','')) != -1) {
                $(th).addClass('open');
            }
        });};
</script>
                <div class="page-content">
                    <div class="main">
                        <div class="main_01">
                            <div class="title">
                                物联网 </div>
                            <div class="one">
                                <a href="http://60.247.225.87:6767/iot/index">
                                    <div class="span-01" style="background:#bd6de2;"><i class="icon-sitemap" style="font-size: 30px;"></i></div>
                                </a>
                                <a href="http://60.247.225.87:6767/iot/index">
                                    <div class="span-02">设备列表</div>
                                </a>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <!-- <a href="http://60.247.225.87:6767/set/button" class="btn green big btn-block" style="width:96%;margin:0 auto;margin-top:50px;margin-bottom:50px;">设置按钮</a> -->
                </div>
        </div>
        <script src="/static/media/js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="/static/media/js/bootstrap.min.js" type="text/javascript"></script>
        <!--[if lt IE 9]>
            <script src="/static/media/js/excanvas.min.js">
            </script>
            <script src="/static/media/js/respond.min.js">
            </script>
        <![endif]-->
        <script src="/static/media/js/app.js" type="text/javascript"></script>
        <script>
            jQuery(document).ready(function () {
                App.init(); // initlayout and core plugins
            });
        </script>
        <!-- END JAVASCRIPTS -->
        <!-- END BODY -->
</body>

</html>