<?php /*a:2:{s:43:"/www/wwwroot/iot/app/view/iot/response.html";i:1733021756;s:42:"/www/wwwroot/iot/app/view/Public/head.html";i:1733021756;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
<title>IOT物联网系统</title>
<meta content="width=device-width, initial-scale=1.0,user-scalable=no" name="viewport" />
<meta name="renderer" content="webkit" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="shortcut icon" href="/static/media/image/favicon.ico" />
<script src="/static/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/static/js/vue.js"></script>
<link href="/static/css/css.css" rel="stylesheet" type="text/css" />
<link href="/static/js/layui/css/layui.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/static/js/layui/layui.js"></script>
<script type="text/javascript" src="/static/js/laydate/laydate.js"></script>
<script type="text/javascript">
    layui.use(['layer'], function () {
        var layer = layui.layer
    });

</script>
<style>
    [v-cloak] {
        display: none;
    }
</style>
    <link href="/static/media/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-responsive.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/default.css" rel="stylesheet" type="text/css" id="style_color" />
    <link href="/static/media/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/style-metro.css" rel="stylesheet" type="text/css" />
    <link href="/static/media/css/uniform.default.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="/static/media/css/select2_metro.css" />
    <link rel="stylesheet" type="text/css" href="/static/media/css/chosen.css" />
    <style>
        .addPsize{position: absolute;left: 10px;top:10px;}
    </style>
</head>

<body class="page-header-fixed">
    <div>
        <div class="tab-pane active" id="app" v-cloak>
            <div class="portlet box yellow ">
                <div class="portlet-body">
                    <table class="table table-bordered table-hover table-striped">
                        <tbody>
                            <template v-for="(item, index) in list">
                                <tr>
                                    <td rowspan="2">
                                        模式{{index}}
                                    </td>
                                    <td>
                                        触发指令
                                    </td>
                                    <td>
                                        <input type="radio" v-model="item.stype" value="0" /> ASCII
                                        <input type="radio" v-model="item.stype" value="1" /> HEX
                                        <br>
                                        <textarea class="m-wrap" rows="3" style="width:400px;" v-model.trim="item.sval"></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        回复指令
                                    </td>
                                    <td>
                                        <input type="radio" v-model="item.rtype" value="0" /> ASCII
                                        <input type="radio" v-model="item.rtype" value="1" /> HEX
                                        <br>
                                        <textarea class="m-wrap" rows="3" style="width:400px;" v-model.trim="item.rval"></textarea>
                                    </td>
                                </tr>
                            </template>
                            <tr>
                                <td>
                                    操作
                                </td>
                                <td colspan="2">
                                    <a href="javascript:;" @click="ok" class="layui-btn layui-btn-danger">确定</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        var app = new Vue({
            el: '#app',
            data: {
                list: []
            },
            created: function() {
                var th = this;
                th.getResponseInfo();
            },
            methods: {
                getResponseInfo: function() {
                    var th = this;
                    $.ajax({
                        type: 'post',
                        url: "http://60.247.225.87:6767/iot/getResponseInfo",
                        timeout: 5000,
                        data: 'id=<?php echo htmlentities($id); ?>',
                        dataType: 'json',
                        success: function(data) {
                            if (data.status == 'success') {
                                th.list = data.info;
                            }
                        }
                    });
                },
                ok: function() {
                    var th = this;
                    $.ajax({
                        type: 'post',
                        url: "http://60.247.225.87:6767/iot/addResponseAjax",
                        timeout: 5000,
                        data: 'id=<?php echo htmlentities($id); ?>&list=' + JSON.stringify(th.list),
                        dataType: 'json',
                        success: function(data) {
                            layer.closeAll();
                            layer.msg(data.info);
                            if (data.status == 'success') {
                                setTimeout(function() {
                                    parent.location.reload();
                                }, 500);
                            }
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            //TODO: 处理status， http status code，超时 408
                            // 注意：如果发生了错误，错误信息（第二个参数）除了得到null之外，还可能
                            //是"timeout", "error", "notmodified" 和 "parsererror"。
                            layer.closeAll('loading');
                            //layer.alert('操作失败,请重试!');
                            layer.alert(errorThrown);
                        }
                    });
                }
            }
        })
</script>
</body>

</html>